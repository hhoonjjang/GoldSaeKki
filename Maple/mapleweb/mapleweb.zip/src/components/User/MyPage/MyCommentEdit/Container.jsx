import MyCommentEditComponent from "./Component";

const MyCommentEditContainer = () => {
  return <MyCommentEditComponent />;
};

export default MyCommentEditContainer;
