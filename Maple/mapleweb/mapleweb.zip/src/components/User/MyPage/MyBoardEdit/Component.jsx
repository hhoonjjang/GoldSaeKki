import styled from "styled-components";

const MyBoardEditComponent = () => {
  return <div>내가 쓴글 관리입니다.</div>;
};

export default MyBoardEditComponent;
