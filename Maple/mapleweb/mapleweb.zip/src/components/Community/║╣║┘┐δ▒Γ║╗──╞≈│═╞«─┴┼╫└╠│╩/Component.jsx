import styled from 'styled-components';
// import { Link, Routes, Route } from "react-router-dom";

const ListComponent = () => {

    return (
        <ContentBox>
            하이
        </ContentBox>
    );
};

export default ListComponent;

const ContentBox = styled.div`
`;