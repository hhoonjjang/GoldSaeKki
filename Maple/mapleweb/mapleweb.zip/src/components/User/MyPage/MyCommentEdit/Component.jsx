import styled from "styled-components";

const MyCommentEditComponent = () => {
  return <div>내가 쓴 댓글 관리입니다.</div>;
};

export default MyCommentEditComponent;
