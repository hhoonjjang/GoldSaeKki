import styled from "styled-components";
import LeftTabsExample from "../Tabs/Component";
const ServiceComponent = () => {
  return (
    <ServiceBox>
      <LeftTabsExample />
    </ServiceBox>
  );
};

export default ServiceComponent;

const ServiceBox = styled.div``;
