import { Router } from "express";
import db from "../models/index.js";
const router = Router();

router.post("/displaycategory", async (req, res) => {
  const tempCategory = await db.Category.findAll({
    include: [
      {
        model: db.Helptext,
        as: "Help",
        include: [
          {
            model: db.Helptextchild,
            as: "Child",
          },
        ],
        order: [[{ model: db.Helptext, as: "Help" }, "id", "DESC"]],
      },
    ],
  });
  console.log("하이");

  console.log(tempCategory[0].Help);
  console.log("하이");

  res.send(tempCategory);
});

export default router;
