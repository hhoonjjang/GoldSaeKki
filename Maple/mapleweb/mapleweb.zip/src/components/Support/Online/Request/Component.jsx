import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import styled from "styled-components";

function UncontrolledExample({ categoryArr }) {
  console.log(categoryArr);
  return (
    <Tabs
      defaultActiveKey="profile"
      id="uncontrolled-tab-example"
      className="mb-3"
    >
      {categoryArr.map((item, idx) => (
        <Tab eventKey={item.category} title={item.category} key={`Tab-${idx}`}>
          <CategoryBox>
            {item.Help.map((item, idx) => (
              <div key={`category-${idx}`}>{item.text}</div>
            ))}
          </CategoryBox>
        </Tab>
      ))}
    </Tabs>
  );
}

export default UncontrolledExample;

const CategoryBox = styled.div`
  display: flex;
  justify-content: space-between;
  width: 80%;
  flex-wrap: wrap;
`;
