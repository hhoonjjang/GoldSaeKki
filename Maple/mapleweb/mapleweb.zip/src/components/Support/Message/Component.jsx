const MessageComponent = () => {
  return <div>메세지컴포넌트</div>;
};

export default MessageComponent;
