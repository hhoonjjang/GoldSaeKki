import MessageComponent from "./Component";

const MessageContainer = () => {
  return <MessageComponent />;
};

export default MessageContainer;
