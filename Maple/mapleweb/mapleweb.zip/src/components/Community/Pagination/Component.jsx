import styled from 'styled-components';
// import { Link, Routes, Route } from "react-router-dom";

const CommentComponent = () => {

    return (
        <ContentBox>
            하이
        </ContentBox>
    );
};

export default CommentComponent;

const ContentBox = styled.div`
`;