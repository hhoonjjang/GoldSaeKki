import OnlineComponent from "./Component";

const OnlineContainer = () => {
  return <OnlineComponent />;
};

export default OnlineContainer;
