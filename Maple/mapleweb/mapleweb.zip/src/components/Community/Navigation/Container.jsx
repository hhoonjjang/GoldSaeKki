import NavigationComponent from "./Component";

const NavigationContainer = () =>{
    
    

    return (
        <NavigationComponent />
    );
}

export default NavigationContainer;