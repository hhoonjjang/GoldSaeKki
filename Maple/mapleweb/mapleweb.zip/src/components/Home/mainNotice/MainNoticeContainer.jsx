import MainNoticeComponent from "./MainNoticeComponent";

const MainNoticeContainer = () => {
  return <MainNoticeComponent></MainNoticeComponent>;
};

export default MainNoticeContainer;
