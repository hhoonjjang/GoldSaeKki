import MyBoardEditComponent from "./Component";

const MyBoardEditContainer = () => {
  return <MyBoardEditComponent />;
};

export default MyBoardEditContainer;
